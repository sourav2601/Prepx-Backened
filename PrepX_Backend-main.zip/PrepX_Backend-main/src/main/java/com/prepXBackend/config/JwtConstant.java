package com.prepXBackend.config;

public class JwtConstant {
	
	public static final String SECRETE_KEY="KMFVKENRJFNEANFJAKWNFAEWN FWEFNLKEWNFELWKNF";
	
	public static final String JWT_HEADER="Authorization";

}
